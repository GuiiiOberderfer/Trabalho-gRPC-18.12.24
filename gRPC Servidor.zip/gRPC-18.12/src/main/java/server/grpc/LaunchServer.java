package server.grpc;

import io.grpc.Server;
import io.grpc.ServerBuilder;

import java.io.IOException;

public class LaunchServer {
    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("Inicializando o servidor gRPC...");

        Server server = ServerBuilder.forPort(8080).addService(new HelloServiceImpl()).build();

        server.start();
        System.out.println("Servidor iniciado em: localhost:8080");
        System.out.println("Servidor em funcionamento! Aguardando conexões de clientes...");
        System.out.println("Pressione Ctrl+F2 para encerrar.");

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Desligando servidor...");
            server.shutdown();
            System.out.println("Servidor desligado com sucesso!");
        }));

        server.awaitTermination();
    }
}
