package server.grpc;

import com.prot.launch.Hello;
import com.prot.launch.HelloRequest;
import com.prot.launch.HelloResponse;
import com.prot.launch.HelloServiceGrpc;
import io.grpc.stub.StreamObserver;

public class HelloServiceImpl extends HelloServiceGrpc.HelloServiceImplBase {

    private int requestCount = 0;

    @Override
    public void hello(HelloRequest request, StreamObserver<HelloResponse> responseObserver) {
        requestCount++;

        Hello hello = request.getLaunch();
        String input = hello.getName();

        String resposta;

        if (requestCount == 1) {
            resposta = "Olá, " + input + "! Bem-vindo ao serviço gRPC.";
            System.out.println("Recebido nome: " + input);
        } else {
            resposta = "Frase recebida com sucesso: " + input;
            System.out.println("Recebida frase: " + input);
        }

        HelloResponse response = HelloResponse.newBuilder().setResposta(resposta).build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();

        System.out.println("Resposta enviada ao cliente: " + resposta);
    }
}
