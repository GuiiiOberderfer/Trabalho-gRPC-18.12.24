package server.client;

import com.prot.launch.Hello;
import com.prot.launch.HelloRequest;
import com.prot.launch.HelloResponse;
import com.prot.launch.HelloServiceGrpc;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.Scanner;

public class LaunchClient {
    public static void main(String[] args) {
        System.out.println("!--- Cliente gRPC ---!");

        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8080).usePlaintext().build();
        System.out.println("Estabelecendo conexão com o servidor...");

        HelloServiceGrpc.HelloServiceBlockingStub stub = HelloServiceGrpc.newBlockingStub(channel);
        System.out.println("Conexão estabelecida com sucesso!");

        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite seu nome: ");
        String nome = scanner.nextLine();

        Hello helloName = Hello.newBuilder().setName(nome).build();
        HelloRequest nameRequest = HelloRequest.newBuilder().setLaunch(helloName).build();

        System.out.println("Salvando...");
        HelloResponse nameResponse = stub.hello(nameRequest);
        System.out.println(nameResponse.getResposta());

        System.out.print("Digite uma frase para enviar ao servidor: ");
        String frase = scanner.nextLine();

        Hello helloPhrase = Hello.newBuilder().setName(frase).build();
        HelloRequest phraseRequest = HelloRequest.newBuilder().setLaunch(helloPhrase).build();

        System.out.println("Enviando frase ao servidor...");
        HelloResponse phraseResponse = stub.hello(phraseRequest);
        System.out.println("Resposta do servidor: " + phraseResponse.getResposta());

        System.out.println("Encerrando conexão com o servidor...");
        channel.shutdown();
        System.out.println("Conexão encerrada.");
    }
}
